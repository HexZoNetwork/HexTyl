<?php

namespace Pterodactyl\Contracts\Repository;

interface ApiPermissionRepositoryInterface extends RepositoryInterface
{
}
